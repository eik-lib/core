var a=foo=1;window.alert(a),window.alert("bar");
//# sourceMappingURL=index.js.map
