!function(){"use strict";var o=foo=1;window.alert(o),window.alert("bar")}();
//# sourceMappingURL=index.js.map
