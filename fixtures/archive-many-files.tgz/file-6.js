export default 6;
