export default 26;
